# MyCryptoDevPay 💰

**The Open-Source Compensation Benchmarking Platform for the Crypto Industry**

---

## 🎯 What Is This?

MyCryptoDevPay is a web-based platform that provides transparent, data-driven salary benchmarks for crypto/blockchain professionals. Instead of relying on guesswork or outdated data, it uses a rigorous **points-factor evaluation methodology** (adapted from the industry-standard JobLink system) to objectively assess roles and determine fair compensation.

### The Problem We Solve

The crypto industry suffers from:
- **Opaque compensation data** - No one knows what they should really be paid
- **Title inflation** - A "Senior Engineer" at one company is an "Engineer II" at another
- **Token compensation confusion** - How do you value volatile token grants?
- **No standardization** - Every company invents their own leveling system

### Our Solution

1. **Standardized Job Catalog** - 100+ crypto-specific roles mapped to consistent levels
2. **Objective Role Evaluation** - AI analyzes job descriptions and scores them on 5 factors
3. **Transparent Methodology** - Open-source scoring system anyone can audit
4. **Crowdsourced Data** - Community-contributed salary data (anonymized)
5. **Global Parity Focus** - Anchored to US market rates for remote-first teams

---

## 🔬 How It Works

### The Evaluation Methodology

Every role is scored across **5 factors** (max 1000 points total):

| Factor | Weight | What It Measures |
|--------|--------|------------------|
| **Knowledge & Application** | 30% | Required expertise and how it's applied |
| **Problem Solving** | 15% | Complexity of challenges faced |
| **Interaction** | 15% | Communication and stakeholder management |
| **Impact** | 30% | Scope of influence on the organization |
| **Accountability** | 10% | Direct vs. indirect responsibility |

### Points → Grades → Levels → Compensation

| Grade | Points | Level | Example Titles |
|-------|--------|-------|----------------|
| 1-3 | 100-205 | IC1 | Junior, Engineer I, Associate |
| 4-5 | 206-329 | IC2 | Engineer II, Mid-level |
| 6-7 | 330-485 | IC3 | Senior, Engineer III |
| 8-9 | 486-641 | IC4 | Staff, Tech Lead |
| 10-11 | 642-790 | IC5 | Principal, Architect |
| 12-13 | 791-906 | IC6 | Distinguished, Fellow |
| 14-15 | 907-1000 | VP+ | VP, CTO, C-Level |

### Crypto-Specific Adjustments

- **Crypto-Native Bonus**: +5% to Knowledge score for blockchain-native roles
- **Security-Critical Uplift**: +10% to Problem Solving for auditors, security engineers
- **Token Risk Adjustment**: Discounts for volatile/illiquid token compensation

---

## 📊 Features

### 1. Two Ways to Find Your Salary

**Option A: Paste a Job Description**
- AI analyzes the JD
- Suggests matching standard title
- Detects level, family, and factors
- Flags misalignments

**Option B: Manual Selection**
- Choose job family → subfamily → level
- Select company stage and size
- Get instant compensation ranges

### 2. Comprehensive Job Catalog

**7 Job Families:**
- 🔧 **Engineering** - Protocol, Smart Contract, Backend, Frontend, DevOps, Security, Data
- 📋 **Product & Design** - Product Management, UX/UI, Research
- 💼 **Business** - BD, Partnerships, Sales
- ⚙️ **Operations** - Legal, Finance, HR, Ops
- 📣 **Marketing & Community** - Marketing, Community, DevRel
- 🎓 **Research** - Cryptography, Economics, Academic
- 🏛️ **Governance** - Governance Lead, Delegates, DAO Ops, Tokenomics

### 3. Compensation Breakdown

For each role, see:
- **25th / 50th / 75th / 90th percentiles**
- **Base Salary** (stable, in USD)
- **STI** (Short-Term Incentive / Bonus)
- **LTI** (Long-Term Incentive / Equity / Tokens)

### 4. Crowdsourced Data Collection

Users can anonymously submit their compensation with verification options.

---

## 🚀 Getting Started

### Run Locally

```bash
git clone https://github.com/KerberusPrime/mycryptodevpay.git
cd mycryptodevpay
npm install
npm run dev
```

### Deploy

Push to GitHub and connect to Vercel for automatic deployments.

---

## 📈 Roadmap

### Phase 1 (Current - MVP) ✅
- Job catalog with crypto roles
- Points-factor evaluation engine
- AI job description analyzer
- Compensation percentile display
- Anonymous data submission

### Phase 2 (Next)
- Database backend (Supabase)
- CoinMarketCap API for token prices
- Token Risk Adjustment calculator
- Admin dashboard

### Phase 3 (Future)
- Geographic adjustments
- Company-specific benchmarking
- Trends over time
- API access

---

## 📄 License

MIT License - Use it however you want.

---

## 🔗 Links

- **Live App**: https://mycryptodevpay.vercel.app
- **GitHub**: https://github.com/KerberusPrime/mycryptodevpay

---

**Built with ❤️ for the crypto community**
